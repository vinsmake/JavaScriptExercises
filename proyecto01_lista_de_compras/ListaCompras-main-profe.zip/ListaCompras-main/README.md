# ListaCompras
Se muestra una página que permite crear una lista de compras de forma dinámica usando HTML y Javascript

![Image](https://github.com/jcgeneration/ListaCompras/blob/develop/img/SplashScreen.png)

